﻿# Path to the cert file
$CertPath = Join-Path $PSScriptRoot "GEMultilin.cer"
$CertPath1 = Join-Path $PSScriptRoot "GeneralElectricCompany.cer"

# Load the certificate to get its thumbprint
$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($CertPath)
$thumb = $cert.Thumbprint

Write-Host "Removing certificate with Thumbprint $thumb from TrustedPublisher..."

# Remove from TrustedPublisher store
certutil.exe -delstore "TrustedPublisher" $thumb

# Load the certificate to get its thumbprint
$cert1 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($CertPath1)
$thumb1 = $cert.Thumbprint

Write-Host "Removing certificate with Thumbprint $thumb1 from TrustedPublisher..."

# Remove from TrustedPublisher store
certutil.exe -delstore "TrustedPublisher" $thumb1


# Keywords to search for
$Keywords = @(
    "EnerVista D&I Setup",
    "GE RNDIS Driver",
    "GE Bridge RNDIS Driver",
    "GE GS D&I and GE 8Series RNDIS Driver"
)

# Registry paths (64-bit + 32-bit)
$RegPaths = @(
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
)

$results = foreach ($path in $RegPaths) {
    foreach ($keyword in $Keywords) {
        Get-ChildItem -Path $path | ForEach-Object {
            $props = Get-ItemProperty -Path $_.PsPath -ErrorAction SilentlyContinue
            if ($props.DisplayName -and $props.DisplayName -like "*$keyword*") {
                [PSCustomObject]@{
                    DisplayName  = $props.DisplayName
                    PsChildName  = $_.PSChildName
                    RegistryPath = $path
                }
            }
        }
    }
}

if ($results) {
    $results | Format-Table -AutoSize
    foreach($result in $results){
        if($result.PsChildName.StartsWith('InstallShield_'))
        {
           Remove-Item -Path $(Join-Path $result.RegistryPath $result.PsChildName) -Force -Recurse -ErrorAction SilentlyContinue 
        }else{
            Start-Process -FilePath msiexec -ArgumentList "/x $($result.PsChildName) /qn /norestart" -Wait -NoNewWindow
        }
    }
} else {
    Write-Host "No matching entries found."
}