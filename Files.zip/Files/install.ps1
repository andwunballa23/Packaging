﻿# ================================
# Script: Install-DandI.ps1
# Purpose: Automate D&I installation with certificates and MSI sub-installers
# ================================

# Define paths relative to script location
$BasePath   = $PSScriptRoot
$ExePath    = Join-Path $BasePath "D&ISetup420.exe"
$IssPath    = Join-Path $BasePath "install.iss"

$Certs      = @(
    (Join-Path $BasePath "GEMultilin.cer"),
    (Join-Path $BasePath "GeneralElectricCompany.cer")
)
$OthersPath = Join-Path $BasePath "others"

# -------------------------------
# Function: Add-Certificate
# -------------------------------
function Add-Certificate {
    param([string]$CertPath)

    if (Test-Path $CertPath) {
        Write-Host "Adding certificate $CertPath to TrustedPublisher store..."
        certutil.exe -addstore -f "TrustedPublisher" $CertPath | Out-Null
    } else {
        Write-Warning "Certificate not found: $CertPath"
    }
}

# -------------------------------
# Function: Install-MSI
# -------------------------------
function Install-MSI {
    param([string]$MsiPath)

    if (Test-Path $MsiPath) {
        Write-Host "Running MSI installer: $MsiPath"
        Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$MsiPath`" /qn /norestart" -Wait -NoNewWindow
    } else {
        Write-Warning "MSI file not found: $MsiPath"
    }
}

# -------------------------------
# Step 1: Add Certificates
# -------------------------------
foreach ($cert in $Certs) {
    Add-Certificate -CertPath $cert
}

# -------------------------------
# Step 2: Run Main Installer
# -------------------------------
if ((Test-Path $ExePath) -and (Test-Path $IssPath)) {
    Write-Host "Running main installer silently..."
    Start-Process -FilePath $ExePath -ArgumentList "-s -f1`"$IssPath`"" -Wait -NoNewWindow
    Write-Host "Main installation completed. Log: $LogPath"
} else {
    Write-Warning "Main installer or ISS file missing."
}

# -------------------------------
# Step 3: Sequential MSI Installation
# -------------------------------
# Example: explicitly define MSI order
$MsiFiles = @(
    $(Join-Path $OthersPath "1\GE_RNDIS.msi"),
    $(Join-Path $OthersPath "2\GE_RNDIS_400.msi"),
    $(Join-Path $OthersPath "3\GE Bridge RNDIS Driver.msi")
)

foreach ($msi in $MsiFiles) {
    Install-MSI -MsiPath $msi
}

Write-Host "All installations completed."
